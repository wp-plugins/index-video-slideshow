=== Index Video Slideshow ===
Contributors: Ghabriel Rodrigues (ghabrielsp@hotmail.com - ghabriel@indexvirtual.com), Silvio Lucena Junior (silvio_lucena_junior@hotmail.com - silvio@indexvirtual.com), M. Malsup (http://jquery.malsup.com/cycle/), Index Agency (http://indexdigital.com.br/)

Donate link: http://indexdigital.com.br
Tags: slideshow, videos, posts, items, jquery, jcycle
Requires at least: 2.9
Tested up to: 2.9.2
Stable tag: 1.0

Create a slideshow that returns a string php containing a list of videos registered by the administrator 

using a jquery plugin for transitions

== Description ==

Create a slideshow that returns a string php containing a list of videos registered by the administrator 

using a jquery plugin (http://jquery.malsup.com/cycle/) for slider transition effects

1. Upload `index-video-slideshow.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Download the JQuery Api (http://code.jquery.com/jquery-1.4.2.min.js) and JCycle Plugin 

(http://jquery.malsup.com/cycle/download.html)
4. Import the JQuery Api and JCycle Plugin adding the example code in your header.php
5. Sign your videos
6. Place the function Video::getVideos() in your templates (add the function in php code)


== Installation ==

1. Upload `index-video-slideshow.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Download the JQuery Api (http://code.jquery.com/jquery-1.4.2.min.js) and JCycle Plugin 

(http://jquery.malsup.com/cycle/download.html)
4. Import the JQuery Api and JCycle Plugin adding the example code in your header.php
5. Sign your videos
6. Place the function Video::getVideos() in your templates (add the function in php code)

== Frequently Asked Questions ==

Where do I find JCycle examples and Views ?

From the site http://jquery.malsup.com/cycle/

How do I customize Index Video Slideshow ?

Users can edit the CSS of elements generated (and do just about anything). Not so advanced users 

can contact Index Agency (http://indexdigital.com.br) and either purchase professional support.


== Screenshots ==

None

== Changelog ==

None

== Upgrade Notice ==

None
